package Mojolicious::Plugin::FormRequest;

use Mojo::Base 'Mojolicious::Plugin';
use Mojo::Loader 'load_class';

our $VERSION = '0.01';

sub register {
    my ($self, $app, $conf) = @_;

    $conf ||= {};

    my $dbh       = $conf->{dbh};
    my $namespace = $conf->{namespace} || ($app->moniker . '::Validation');
    my $fail_fast = $conf->{fail_fast} ? 1 : 0;

    if ($dbh) {
        $app->validator->add_check(
            unique => sub {
                my ($v, $name, $value, $table, $column, $ignore_id, $id_column) = @_;
                return undef unless defined $value && length $value;

                my $qt = $dbh->quote_identifier($table);
                my $qc = $dbh->quote_identifier($column);

                my $sql  = "SELECT COUNT(*) FROM $qt WHERE $qc = ?";
                my @bind = ($value);

                if (defined $ignore_id) {
                    my $qid = $dbh->quote_identifier($id_column || 'id');
                    $sql .= " AND $qid != ?";
                    push @bind, $ignore_id;
                }

                my $count = $dbh->selectrow_array($sql, undef, @bind);
                return $count ? 'not_unique' : undef;
            }
        );

        $app->validator->add_check(
            exists => sub {
                my ($v, $name, $value, $table, $column) = @_;
                return undef unless defined $value && length $value;

                my $qt = $dbh->quote_identifier($table);
                my $qc = $dbh->quote_identifier($column);

                my $count = $dbh->selectrow_array(
                    "SELECT COUNT(*) FROM $qt WHERE $qc = ?", undef, $value
                );
                return $count ? undef : 'not_exists';
            }
        );
    }

    $app->helper(
        validate => sub {
            my ($c, $class_name) = @_;

            my $class = $class_name =~ /::/
                ? $class_name
                : "${namespace}::${class_name}";

            # If the class is already defined (inline in a test, preloaded
            # by the app, or provided by an already-required module), use it.
            # Only fall back to loading it from disk if it isn't defined.
            if (!$class->can('rules')) {
                my $err = load_class $class;
                if ($err) {
                    $c->app->log->error("Cannot load validation class $class: $err");
                    return undef;
                }
            }

            # Classes without a constructor are still usable.
            my $obj = $class->can('new') ? $class->new : bless({}, $class);

            if ($obj->can('authorize') && !$obj->authorize($c)) {
                my $accept = $c->req->headers->accept // '';
                if (($c->stash('format') // '') eq 'json' || $accept =~ /json/i) {
                    $c->render(json => { error => 'Forbidden' }, status => 403);
                }
                return undef;
            }

            my $rules    = $obj->can('rules')    ? $obj->rules    : {};
            my $filters  = $obj->can('filters')  ? $obj->filters  : {};
            my $messages = $obj->can('messages') ? $obj->messages : {};

            # Prefer a JSON object body; otherwise use query/form params.
            my $json   = $c->req->json;
            my $params = ref $json eq 'HASH'
                ? { %$json }
                : $c->req->params->to_hash;

            for my $field (keys %$filters) {
                next unless exists $params->{$field};
                $params->{$field} = $filters->{$field}->($params->{$field});
            }

            my $v = $c->app->validator->validation;
            $v->input($params);

            my %errors;

            FIELD: for my $field (sort keys %$rules) {
                my @rules = @{ $rules->{$field} };

                # Only required/optional take the field name and set the
                # topic; all other checks run against the current topic.
                my $first = ref $rules[0] eq 'ARRAY' ? $rules[0][0] : $rules[0];
                $v->optional($field) unless defined $first && $first =~ /^(?:required|optional)$/;

                for my $rule (@rules) {
                    my ($check, @args) = ref $rule eq 'ARRAY' ? @$rule : ($rule);
                    if ($check eq 'required' || $check eq 'optional') {
                        $v->$check($field, @args);
                    }
                    else {
                        $v->$check(@args);
                    }
                }

                if ($v->has_error($field)) {
                    # error() returns an arrayref: [check_name, result, @args]
                    my $check = $v->error($field)->[0];
                    my $msg   = $messages->{"$field.$check"} // $check;
                    $errors{$field} = [$msg];
                    last FIELD if $fail_fast;
                }
            }

            if (%errors) {
                if ($obj->can('on_failure')) {
                    my $handled = $obj->on_failure($c, \%errors);
                    return undef if $handled;
                }
                return _default_failure($c, \%errors);
            }

            my %data;
            for my $field (keys %$rules) {
                $data{$field} = $params->{$field} if exists $params->{$field};
            }

            return \%data;
        }
    );

    return $self;
}

sub _default_failure {
    my ($c, $errors) = @_;

    my $accept = $c->req->headers->accept // '';
    my $format = $c->stash('format')
        || ($accept =~ /json/i ? 'json' : 'html');

    if ($format eq 'json') {
        $c->render(json => { errors => $errors }, status => 422);
    }
    else {
        my $req = $c->req;
        $c->flash(errors => $errors);
        $c->flash(old    => { %{ $req->params->to_hash } });
        $c->redirect_to($req->headers->referrer // '/');
    }

    return undef;
}

1;
__END__

=head1 NAME

Mojolicious::Plugin::FormRequest - Laravel-style form request validation for Mojolicious

=head1 SYNOPSIS

  $app->plugin('FormRequest', dbh => $dbh);
  my $data = $c->validate('UserCreate') or return;

=head1 DESCRIPTION

Laravel-inspired form request validation for Mojolicious.

=head1 LICENSE

Same terms as Perl itself.

=cut
