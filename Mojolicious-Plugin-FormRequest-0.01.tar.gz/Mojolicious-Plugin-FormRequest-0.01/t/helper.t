use Mojo::Base -strict;
use FindBin;
use lib "$FindBin::Bin/../lib";
use Test::More;
use Mojolicious;
use Mojolicious::Plugin::FormRequest;

{
    package TestApp::Validation::UserCreate;
    sub rules {
        return {
            name  => ['required', ['size', 2, 50]],
            email => ['required'],
        };
    }
    sub messages {
        return { 'name.required' => 'Name cannot be empty' };
    }
}

my $app = Mojolicious->new(moniker => 'TestApp');
$app->plugin('FormRequest', namespace => 'TestApp::Validation');

# --- valid case ---
my $c = $app->build_controller;
$c->req->method('POST');
$c->req->url->parse('/users');
$c->req->headers->content_type('application/json');
$c->req->headers->accept('application/json');
$c->req->body('{"name":"Alice","email":"a@b.c"}');

my $data = eval { $c->validate('UserCreate') };
diag "EXCEPTION: $@" if $@;
ok !$@, 'helper did not die';
ok $data, 'valid data returned';
is_deeply $data, { name => 'Alice', email => 'a@b.c' }, 'validated data correct';

# --- invalid case (name missing -> name.required) ---
my $c2 = $app->build_controller;
$c2->req->method('POST');
$c2->req->url->parse('/users');
$c2->req->headers->content_type('application/json');
$c2->req->headers->accept('application/json');
$c2->req->body('{"email":"a@b.c"}');

my $bad = eval { $c2->validate('UserCreate') };
diag "INVALID EXCEPTION: $@" if $@;
ok !$bad, 'invalid data returns undef';
ok $c2->res->code, 'response was rendered';
is $c2->res->code, 422, 'rendered 422';
like $c2->res->body, qr/Name cannot be empty/, 'custom message in body';

done_testing;
