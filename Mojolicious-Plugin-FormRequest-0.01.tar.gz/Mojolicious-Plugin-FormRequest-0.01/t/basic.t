use Mojo::Base -strict;
use Test::More;
use Mojolicious;
use Mojolicious::Plugin::FormRequest;

my $app = Mojolicious->new;
$app->plugin('FormRequest');

# Helpers live in the renderer; this is where the coderef is stored.
ok $app->renderer->helpers->{validate}, 'validate helper registered';
is ref $app->renderer->helpers->{validate}, 'CODE', 'validate helper is a coderef';

# Helpers are callable on controllers via $c->helpers->name.
my $c = $app->build_controller;
ok $c->helpers->can('validate'), 'validate reachable via $c->helpers';

done_testing;
