use Mojo::Base -strict;
use Test::More;
use Mojolicious;
use DBI;

my $dbh = DBI->connect('dbi:SQLite::memory:', '', '', { RaiseError => 1 });
$dbh->do('CREATE TABLE users (id INTEGER PRIMARY KEY, email TEXT)');
$dbh->do('CREATE TABLE roles (id INTEGER PRIMARY KEY, name TEXT)');
$dbh->do("INSERT INTO users (email) VALUES ('taken\@example.com')");
$dbh->do("INSERT INTO roles (name) VALUES ('admin')");

my $app = Mojolicious->new;
$app->plugin('FormRequest', dbh => $dbh);

my $validator = $app->validator;

# unique: existing value must fail
my $v = $validator->validation;
$v->input({ email => 'taken@example.com' });
$v->required('email')->check('unique', 'users', 'email');
ok !$v->is_valid('email'), 'unique rejects existing email';

# unique: new value must pass
$v = $validator->validation;
$v->input({ email => 'fresh@example.com' });
$v->required('email')->check('unique', 'users', 'email');
ok $v->is_valid('email'), 'unique accepts new email';

# unique: ignore_id lets an update pass
$v = $validator->validation;
$v->input({ email => 'taken@example.com' });
$v->required('email')->check('unique', 'users', 'email', 1);
ok $v->is_valid('email'), 'unique with ignore_id accepts the same row';

# exists: existing value passes
$v = $validator->validation;
$v->input({ role => 1 });
$v->required('role')->check('exists', 'roles', 'id');
ok $v->is_valid('role'), 'exists accepts an existing row';

# exists: missing value fails
$v = $validator->validation;
$v->input({ role => 999 });
$v->required('role')->check('exists', 'roles', 'id');
ok !$v->is_valid('role'), 'exists rejects a missing row';

done_testing;
