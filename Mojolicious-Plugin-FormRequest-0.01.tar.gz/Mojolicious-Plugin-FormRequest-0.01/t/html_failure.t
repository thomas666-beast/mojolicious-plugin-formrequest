use Mojo::Base -strict;
use FindBin;
use lib "$FindBin::Bin/../lib";
use Test::More;
use Test::Mojo;
use Mojolicious;
use Mojolicious::Plugin::FormRequest;

{
    package TestApp::Validation::UserCreate;
    sub rules {
        return {
            name  => ['required'],
            email => ['required'],
        };
    }
    sub messages {
        return { 'name.required' => 'Name cannot be empty' };
    }
}

my $app = Mojolicious->new(moniker => 'TestApp');
$app->plugin('FormRequest', namespace => 'TestApp::Validation');

$app->routes->get('/form' => sub {
    my $c = shift;
    $c->render(text => 'form page');
});

$app->routes->post('/users' => sub {
    my $c = shift;
    $c->redirect_to('/form') unless $c->req->headers->referrer;
    my $data = $c->validate('UserCreate') or return;
    $c->render(text => 'ok');
});

my $t = Test::Mojo->new($app);

# HTML POST (no .json suffix, HTML Accept) -> flash + redirect
$t->post_ok('/users' => form => { email => 'a@b.c' })
  ->status_is(302);

like $t->tx->res->headers->location, qr{/}, 'redirected';

# flash survives into the next request
$t->get_ok('/form')->status_is(200);

done_testing;
